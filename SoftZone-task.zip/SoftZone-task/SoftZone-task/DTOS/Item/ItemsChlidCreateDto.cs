﻿namespace SoftZone_task.DTOS.Item
{
    public class ItemsChlidCreateDto
    {
        public int ItemId { get; set; }

    }
}
