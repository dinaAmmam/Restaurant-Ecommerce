﻿namespace SoftZone_task.DTOS.Item
{
    public class ItemChildReadDTO
    {
        public int ItemId { get; set; }
        public string? Title { get; set; }
        public string? Description { get; set; }
        public string? Image { get; set; }
        public int? Price { get; set; }
    }
}
