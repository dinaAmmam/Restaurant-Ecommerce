﻿namespace SoftZone_task.DTOS.Restaurant
{
    public class RestaurantChlidReadDto
    {
        public int RestaurantId { get; set; }
        public string? RestaurantName { get; set; }
    }
}
